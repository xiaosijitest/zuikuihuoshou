+++++++
Contact
+++++++

Mailing list
============

Mailing list: ``zuikuihuoshou AT lists.tuxfamily.org``

* `Read archives on mail-archives.com <http://www.mail-archive.com/zuikuihuoshou%40lists.tuxfamily.org/>`_
* `Mailing list archives on Gmane.org
  <http://dir.gmane.org/gmane.comp.python.zuikuihuoshou>`_: Read mailing list using
  HTTP, NNTP or RSS

* To subscribe, send an email with subject ``subscribe`` (and empty body) to
  ``zuikuihuoshou-request@lists.tux(...).org``
* To unsubscribe, send an email with subject ``unsubscribe`` (and empty body)
  to ``zuikuihuoshou-request@lists.tux(...).org``
* You have to subscribe to post email.
* Created October 22nd 2006

