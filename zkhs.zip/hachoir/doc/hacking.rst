++++++++++++
Hack Hachoir
++++++++++++

Run tests
=========

Using tox
---------

Install tox (``pip install tox``) and then run tox::

    tox

Manually
--------

Run tests manually::

    python3 runtests.py
