#!/usr/bin/env python3
from zuikuihuoshou.subfile.main import main
main()
