from zuikuihuoshou.metadata.main import main
main()
