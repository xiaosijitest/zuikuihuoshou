from zuikuihuoshou.metadata.metadata import extractMetadata  # noqa

# Just import the module,
# each module use registerExtractor() method
import zuikuihuoshou.metadata.archive  # noqa
import zuikuihuoshou.metadata.audio  # noqa
import zuikuihuoshou.metadata.file_system  # noqa
import zuikuihuoshou.metadata.image  # noqa
import zuikuihuoshou.metadata.jpeg  # noqa
import zuikuihuoshou.metadata.misc  # noqa
import zuikuihuoshou.metadata.program  # noqa
import zuikuihuoshou.metadata.riff  # noqa
import zuikuihuoshou.metadata.video  # noqa
import zuikuihuoshou.metadata.cr2 # noqa