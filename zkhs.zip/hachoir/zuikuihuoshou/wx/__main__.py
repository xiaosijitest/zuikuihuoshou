from zuikuihuoshou.wx.main import main
main()
